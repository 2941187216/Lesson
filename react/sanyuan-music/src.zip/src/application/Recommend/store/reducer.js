// import * as actionTypes from './constant';
const defaultStatus = {
  recommendList:[]
}
export default (state = defaultStatus, action) => {
  switch (action.type) {
    default:
      return state
  }
}